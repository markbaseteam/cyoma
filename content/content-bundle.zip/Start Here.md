[[7814 by Global Communication]]

4:14 by Global Communications

Country

Classic Country

Hurt by Johnny Cash

Alt Country

Random Rules by Silver Jews

Electronic

EDM

Downtempo

Sour Times by Portishead

Drum and Bass

GORE-TEX COVERS MY SOUL by Blksmith

House

Face to Face by Daft Punk

Vaporwave

Eco Zones by Blank Banshee

IDM

Roygbiv by Music Has The Right To Children

Hip Hop

Instrumental

Sacrifice (Beat-A-Holic Thoughts) by Madlib

Industrial

Hustle Bones by Death Grips

Abstract

All Caps by MF DOOM

Alternative Rap

Answer by Tyler The Creator

West Coast

Lil’ Ghetto Boy by Dr.Dre

East Coast

The World Is Yours by Nas

South

Ridin’ Dirty by UGK

Memphis

Stash Pot by Koopsta Knicca

Cloud Rap

I’m God by Lil B

Trap

Hard in Da Paint by Wack Flocka Flame

  

Jazz

Avant Garde/ Free

A Love Supreme, Pt. I - Acknowledgment

Bossanova

The Girl From Ipanema by Stan Getz

Cool

So What by Miles Davis 

Vocal

In The Wee Small Hours by Frank Sinatra

Fusion

ミッドナイト・ランデブー by CASIOPEA

Bebop

Bouncin’ With Bud by Bud Powell

Modal

My Favourite Things by John Coltrane

  
  

Pop

Art Pop

Running Up The Hill by Kate Bush

Twee Pop

Get Me Away FRom Here, I’m Dying by Belle and Sebastian

Dance

Rock with You by Michael Jackson

80s Revival

When I Needed You by Carly Rae Jepsen

Indie Pop

Shuggie by Foxygen

Hyperpop

Forever by Charli XCX

City Pop

Plastic Love by Mariya Takeuchi

Jangle Pop

The Boy with The Thorn in His Side by The Smiths

Indietronica

Electric Feel by MGMT

  

Rock

  

Shoegaze

When You Sleep by my bloody valentine

Dreampop

Heaven or Las Vegas by Cocteau Twins

Grunge

In Bloom by Niravana

Indie Rock

Someday by The Strokes

Math Rock

Never Meant by American Football

Art Rock

Heroes by David Bowie

Indie Folk

In The Aeroplane Over The Sea by Neutral Milk Hotel

Post Punk

Shadowplay by Joy Division

Punk

Blitzkrieg Bop by Ramones

Post Rock

Sink Is Busted by JUNE OF 44

Prog Rock

21st Century Schizoid Man by King Crimson

Psychedelic Rock

The Crystal Ship by The Doors