**You have begun your Ambient journey! Pick an album you would like to listen to. Click on it to continue your journey.

Teleport me to the Arctics (I want something colder):
[[Antarctica by Vangelis]]

Teleport me to an empty desert (I want something spookier):
[[Ambient 4 On Land by Brian Eno]]

Teleport me to a calming forest (I want something warmer):
[[Sakura by Susumu Yokota]]

Teleport me to Cherynobyl (I want something more minimal):
[[4 Rooms by Jacob Kirkegaard]]

Teleport me to inside a broken TV (I want something nosier):
[[Love Is A Stream by Jefre Cantu-Ledesma]]

Teleport me to a land of dreams and memories (I want something more retro and glitchier):
[[Replica by Oneohtrix Point Never]]

Teleport me to the loneliest night (I want something more poppier and with vocals):
[[A I A Alien Observer by Grouper]]
